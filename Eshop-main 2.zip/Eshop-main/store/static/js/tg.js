
const TOKEN = "6086320336:AAH5FZfiPclZuN7unozZz6ObUe6zhYaGQPw";
const CHAT_ID = "-1001695116463";
const URI_API = `https://api.telegram.org/bot${ TOKEN }/sendMessage`;
const success = document.getElementById('success');

document.getElementById('tg').addEventListener('submit',function(e){
  e.preventDefault();

  let message = `Заявка с сайта!\n`;
  message += `Сообщение:   ${ this.message.value}`; 

  axios.post(URI_API,{
    chat_id: CHAT_ID,
    parce_mode: 'html',
    text: message
    })
})
